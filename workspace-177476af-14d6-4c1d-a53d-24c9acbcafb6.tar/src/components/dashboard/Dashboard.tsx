'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { WaterChart } from '@/components/charts/WaterChart';
import { WeeklyProgress } from '@/components/charts/WeeklyProgress';
import { useStats } from '@/hooks/useStats';
import { useWaterStore } from '@/store/useWaterStore';
import { 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Target, 
  Droplets, 
  Award,
  Activity,
  Clock
} from 'lucide-react';

export function Dashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState<'today' | 'week' | 'month'>('week');
  const { stats: weekStats, isLoading: weekLoading } = useStats('week');
  const { stats: monthStats, isLoading: monthLoading } = useStats('month');
  const { records } = useWaterStore();

  // Mock weekly data for demonstration
  const weeklyData = [
    { day: 'Lunes', amount: 1800, goal: 2000, percentage: 90, achieved: false },
    { day: 'Martes', amount: 2200, goal: 2000, percentage: 110, achieved: true },
    { day: 'Miércoles', amount: 2000, goal: 2000, percentage: 100, achieved: true },
    { day: 'Jueves', amount: 1500, goal: 2000, percentage: 75, achieved: false },
    { day: 'Viernes', amount: 2300, goal: 2000, percentage: 115, achieved: true },
    { day: 'Sábado', amount: 1900, goal: 2000, percentage: 95, achieved: false },
    { day: 'Domingo', amount: 2100, goal: 2000, percentage: 105, achieved: true },
  ];

  // Mock monthly data for demonstration
  const monthlyData = Array.from({ length: 30 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (29 - i));
    const baseAmount = 1800 + Math.random() * 600;
    const goal = 2000;
    
    return {
      date: date.toISOString(),
      amount: Math.round(baseAmount),
      goal,
      percentage: Math.min((baseAmount / goal) * 100, 100)
    };
  });

  const currentStreak = 3;
  const weeklyGoal = 14000; // 2000ml * 7 days

  const StatCard = ({ 
    title, 
    value, 
    subtitle, 
    icon: Icon, 
    trend, 
    color = "blue" 
  }: {
    title: string;
    value: string | number;
    subtitle?: string;
    icon: any;
    trend?: 'up' | 'down' | 'neutral';
    color?: string;
  }) => (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
            {subtitle && (
              <p className="text-xs text-gray-500">{subtitle}</p>
            )}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100`}>
            <Icon className={`w-6 h-6 text-${color}-600`} />
          </div>
        </div>
        {trend && (
          <div className="flex items-center gap-1 mt-2">
            {trend === 'up' ? (
              <TrendingUp className="w-4 h-4 text-green-500" />
            ) : trend === 'down' ? (
              <TrendingDown className="w-4 h-4 text-red-500" />
            ) : null}
            <span className={`text-xs ${
              trend === 'up' ? 'text-green-500' : 
              trend === 'down' ? 'text-red-500' : 
              'text-gray-500'
            }`}>
              {trend === 'up' ? '+12%' : trend === 'down' ? '-5%' : '0%'} vs período anterior
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Dashboard</h2>
          <p className="text-gray-600">Análisis detallado de tu hidratación</p>
        </div>
        <Tabs value={selectedPeriod} onValueChange={(value) => setSelectedPeriod(value as any)}>
          <TabsList>
            <TabsTrigger value="today">Hoy</TabsTrigger>
            <TabsTrigger value="week">Semana</TabsTrigger>
            <TabsTrigger value="month">Mes</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Consumo Total"
          value={selectedPeriod === 'today' ? '1,250ml' : selectedPeriod === 'week' ? '13,800ml' : '58,200ml'}
          subtitle={selectedPeriod === 'today' ? 'de 2,000ml' : selectedPeriod === 'week' ? 'esta semana' : 'este mes'}
          icon={Droplets}
          trend="up"
          color="blue"
        />
        <StatCard
          title="Promedio Diario"
          value={selectedPeriod === 'today' ? '1,250ml' : selectedPeriod === 'week' ? '1,971ml' : '1,940ml'}
          subtitle="por día"
          icon={Activity}
          trend="up"
          color="green"
        />
        <StatCard
          title="Metas Logradas"
          value={selectedPeriod === 'today' ? '0/1' : selectedPeriod === 'week' ? '4/7' : '22/30'}
          subtitle="días exitosos"
          icon={Target}
          trend="up"
          color="purple"
        />
        <StatCard
          title="Racha Actual"
          value={`${currentStreak} días`}
          subtitle="¡Sigue así!"
          icon={Award}
          trend="neutral"
          color="yellow"
        />
      </div>

      {/* Charts Section */}
      <Tabs value={selectedPeriod} onValueChange={(value) => setSelectedPeriod(value as any)}>
        <TabsContent value="today" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Progreso de Hoy</CardTitle>
                <CardDescription>Tu consumo durante el día</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Droplets className="w-16 h-16 text-blue-500 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold">1,250ml</h3>
                  <p className="text-gray-600">62.5% de tu meta diaria</p>
                  <div className="mt-4">
                    <Badge variant="secondary">750ml restantes</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Registros de Hoy</CardTitle>
                <CardDescription>Tus consumos durante el día</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {records
                    .filter(record => {
                      const today = new Date();
                      const recordDate = new Date(record.timestamp);
                      return recordDate.toDateString() === today.toDateString();
                    })
                    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                    .map((record) => (
                      <div key={record.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <Droplets className="w-4 h-4 text-blue-500" />
                          <div>
                            <p className="font-medium">{record.amount}ml</p>
                            <p className="text-xs text-gray-500">{record.notes}</p>
                          </div>
                        </div>
                        <span className="text-xs text-gray-500">
                          {new Date(record.timestamp).toLocaleTimeString('es-ES', {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="week" className="space-y-6">
          <WeeklyProgress 
            data={weeklyData} 
            weeklyGoal={weeklyGoal} 
            currentStreak={currentStreak}
          />
          
          <WaterChart 
            data={weeklyData.map((day, index) => ({
              date: new Date(Date.now() - (6 - index) * 24 * 60 * 60 * 1000).toISOString(),
              amount: day.amount,
              goal: day.goal,
              percentage: day.percentage
            }))}
            title="Tendencia Semanal"
            description="Tu consumo durante los últimos 7 días"
            type="line"
            period="daily"
          />
        </TabsContent>

        <TabsContent value="month" className="space-y-6">
          <WaterChart 
            data={monthlyData}
            title="Tendencia Mensual"
            description="Tu consumo durante los últimos 30 días"
            type="line"
            period="daily"
          />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-blue-500" />
                  Mejor Día
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-2xl font-bold">2,450ml</p>
                  <p className="text-sm text-gray-600">15 de noviembre</p>
                  <Badge variant="default" className="mt-2">122.5% de la meta</Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-green-500" />
                  Hora Más Activa
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-2xl font-bold">10:00 AM</p>
                  <p className="text-sm text-gray-600">Mañana</p>
                  <Badge variant="secondary" className="mt-2">325ml promedio</Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-purple-500" />
                  Logro del Mes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-2xl font-bold">22 días</p>
                  <p className="text-sm text-gray-600">Metas alcanzadas</p>
                  <Badge variant="outline" className="mt-2">73% de éxito</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}