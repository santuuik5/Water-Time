'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useUserStore } from '@/store/useUserStore';
import { Settings, Droplets, Bell, User, Target } from 'lucide-react';

interface SettingsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsModal({ open, onOpenChange }: SettingsModalProps) {
  const { user, updateUser } = useUserStore();
  const [activeTab, setActiveTab] = useState('profile');
  
  // Profile settings
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [weight, setWeight] = useState(user?.weight?.toString() || '');
  const [activityLevel, setActivityLevel] = useState(user?.activityLevel || 'moderate');
  
  // Water goals
  const [dailyGoal, setDailyGoal] = useState(user?.dailyGoal || 2000);
  
  // Reminder settings
  const [reminderEnabled, setReminderEnabled] = useState(user?.reminderEnabled || true);
  const [reminderInterval, setReminderInterval] = useState(user?.reminderInterval || 60);
  const [reminderStart, setReminderStart] = useState(user?.reminderStart || '08:00');
  const [reminderEnd, setReminderEnd] = useState(user?.reminderEnd || '22:00');

  const handleSave = async () => {
    if (!user) return;

    const updates = {
      name: name || undefined,
      email: email || undefined,
      weight: weight ? parseFloat(weight) : undefined,
      activityLevel: activityLevel || undefined,
      dailyGoal: dailyGoal || undefined,
      reminderEnabled: reminderEnabled || undefined,
      reminderInterval: reminderInterval || undefined,
      reminderStart: reminderStart || undefined,
      reminderEnd: reminderEnd || undefined
    };

    updateUser(updates);
    onOpenChange(false);
  };

  const calculateRecommendedGoal = () => {
    if (!weight) return 2000;
    
    const baseGoal = weight * 35; // 35ml per kg
    
    const activityMultipliers = {
      sedentary: 1.0,
      light: 1.1,
      moderate: 1.2,
      active: 1.3
    };
    
    const multiplier = activityMultipliers[activityLevel as keyof typeof activityMultipliers] || 1.2;
    return Math.round(baseGoal * multiplier);
  };

  const recommendedGoal = calculateRecommendedGoal();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Configuración
          </DialogTitle>
          <DialogDescription>
            Personaliza tu experiencia y ajusta tus metas de hidratación
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile">Perfil</TabsTrigger>
            <TabsTrigger value="goals">Metas</TabsTrigger>
            <TabsTrigger value="reminders">Recordatorios</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Información Personal
                </CardTitle>
                <CardDescription>
                  Actualiza tu información para obtener recomendaciones personalizadas
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Tu nombre"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="tu@email.com"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="weight">Peso (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      placeholder="70"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="activity">Nivel de Actividad</Label>
                    <Select value={activityLevel} onValueChange={setActivityLevel}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sedentary">Sedentario</SelectItem>
                        <SelectItem value="light">Ligero</SelectItem>
                        <SelectItem value="moderate">Moderado</SelectItem>
                        <SelectItem value="active">Activo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {weight && (
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-blue-900">Meta recomendada</h4>
                        <p className="text-sm text-blue-700">
                          Basado en tu peso y nivel de actividad
                        </p>
                      </div>
                      <Badge variant="secondary" className="text-blue-700">
                        {recommendedGoal}ml/día
                      </Badge>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="goals" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Metas de Hidratación
                </CardTitle>
                <CardDescription>
                  Establece tus metas diarias de consumo de agua
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="daily-goal">Meta Diaria</Label>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-blue-600">{dailyGoal}</span>
                      <span className="text-sm text-gray-600">ml</span>
                    </div>
                  </div>
                  <Slider
                    value={[dailyGoal]}
                    onValueChange={(value) => setDailyGoal(value[0])}
                    max={4000}
                    min={500}
                    step={100}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>500ml</span>
                    <span>2000ml</span>
                    <span>4000ml</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <Button
                    variant="outline"
                    onClick={() => setDailyGoal(1500)}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <Droplets className="w-6 h-6 text-blue-500" />
                    <span className="text-sm">Baja</span>
                    <span className="text-xs text-gray-500">1500ml</span>
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setDailyGoal(2000)}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <Droplets className="w-6 h-6 text-green-500" />
                    <span className="text-sm">Estándar</span>
                    <span className="text-xs text-gray-500">2000ml</span>
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setDailyGoal(3000)}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <Droplets className="w-6 h-6 text-purple-500" />
                    <span className="text-sm">Alta</span>
                    <span className="text-xs text-gray-500">3000ml</span>
                  </Button>
                </div>

                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-2">Información de metas</h4>
                  <div className="space-y-2 text-sm text-gray-600">
                    <p>• La meta estándar de 2000ml equivale a 8 vasos de agua</p>
                    <p>• Ajusta según tu peso, actividad y clima</p>
                    <p>• Escucha a tu cuerpo y aumenta si es necesario</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reminders" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Configuración de Recordatorios
                </CardTitle>
                <CardDescription>
                  Personaliza cuándo y cómo recibir recordatorios
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label>Activar recordatorios</Label>
                    <p className="text-sm text-gray-600">
                      Recibe notificaciones para mantenerte hidratado
                    </p>
                  </div>
                  <Switch
                    checked={reminderEnabled}
                    onCheckedChange={setReminderEnabled}
                  />
                </div>

                {reminderEnabled && (
                  <>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="interval">Intervalo de recordatorios</Label>
                        <div className="flex items-center gap-2">
                          <span className="text-lg font-medium">{reminderInterval}</span>
                          <span className="text-sm text-gray-600">minutos</span>
                        </div>
                      </div>
                      <Slider
                        value={[reminderInterval]}
                        onValueChange={(value) => setReminderInterval(value[0])}
                        max={180}
                        min={15}
                        step={15}
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>15 min</span>
                        <span>60 min</span>
                        <span>180 min</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="start-time">Hora de inicio</Label>
                        <Input
                          id="start-time"
                          type="time"
                          value={reminderStart}
                          onChange={(e) => setReminderStart(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="end-time">Hora de fin</Label>
                        <Input
                          id="end-time"
                          type="time"
                          value={reminderEnd}
                          onChange={(e) => setReminderEnd(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="p-4 bg-yellow-50 rounded-lg">
                      <h4 className="font-medium text-yellow-900 mb-2">Resumen de recordatorios</h4>
                      <div className="space-y-1 text-sm text-yellow-700">
                        <p>• Cada {reminderInterval} minutos</p>
                        <p>• De {reminderStart} a {reminderEnd}</p>
                        <p>
                          • Aproximadamente {
                            Math.floor(
                              ((parseInt(reminderEnd.split(':')[0]) * 60 + parseInt(reminderEnd.split(':')[1])) -
                              (parseInt(reminderStart.split(':')[0]) * 60 + parseInt(reminderStart.split(':')[1]))
                            ) / reminderInterval
                          )} recordatorios al día
                        </p>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-3 pt-6 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave}>
            Guardar Cambios
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}