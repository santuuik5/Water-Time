'use client';

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Target, Calendar, TrendingUp } from 'lucide-react';

interface WeekData {
  day: string;
  amount: number;
  goal: number;
  percentage: number;
  achieved: boolean;
}

interface WeeklyProgressProps {
  data: WeekData[];
  weeklyGoal: number;
  currentStreak: number;
}

const COLORS = {
  achieved: '#10b981',
  partial: '#f59e0b',
  notAchieved: '#ef4444'
};

export function WeeklyProgress({ data, weeklyGoal, currentStreak }: WeeklyProgressProps) {
  const totalAmount = data.reduce((sum, day) => sum + day.amount, 0);
  const weeklyPercentage = Math.min((totalAmount / weeklyGoal) * 100, 100);
  const daysAchieved = data.filter(day => day.achieved).length;
  const dayPercentage = (daysAchieved / data.length) * 100;

  const pieData = [
    { name: 'Logrado', value: daysAchieved, color: COLORS.achieved },
    { name: 'Parcial', value: data.filter(d => !d.achieved && d.percentage > 50).length, color: COLORS.partial },
    { name: 'No logrado', value: data.filter(d => !d.achieved && d.percentage <= 50).length, color: COLORS.notAchieved }
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border rounded-lg shadow-lg">
          <p className="font-medium text-sm">{payload[0].name}</p>
          <p className="text-sm text-gray-600">{payload[0].value} días</p>
        </div>
      );
    }
    return null;
  };

  const getDayIcon = (achieved: boolean, percentage: number) => {
    if (achieved) {
      return <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
        <TrendingUp className="w-4 h-4 text-green-600" />
      </div>;
    } else if (percentage > 50) {
      return <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
        <Target className="w-4 h-4 text-yellow-600" />
      </div>;
    } else {
      return <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
        <Target className="w-4 h-4 text-red-600" />
      </div>;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Weekly Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-500" />
            Progreso Semanal
          </CardTitle>
          <CardDescription>
            Resumen de tu consumo de agua esta semana
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Weekly Progress */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Meta semanal</span>
              <Badge variant={weeklyPercentage >= 100 ? "default" : "secondary"}>
                {Math.round(weeklyPercentage)}%
              </Badge>
            </div>
            <Progress value={weeklyPercentage} className="h-3" />
            <p className="text-xs text-gray-600">
              {totalAmount.toLocaleString()}ml de {weeklyGoal.toLocaleString()}ml
            </p>
          </div>

          {/* Day by Day Progress */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Progreso diario</h4>
            <div className="grid grid-cols-7 gap-2">
              {data.map((day, index) => (
                <div key={index} className="text-center">
                  <div className="flex justify-center mb-2">
                    {getDayIcon(day.achieved, day.percentage)}
                  </div>
                  <p className="text-xs font-medium">{day.day.slice(0, 3)}</p>
                  <p className="text-xs text-gray-600">{day.amount}ml</p>
                  <p className="text-xs text-gray-500">{Math.round(day.percentage)}%</p>
                </div>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 pt-4 border-t">
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 text-green-600">
                <TrendingUp className="w-4 h-4" />
                <span className="text-lg font-semibold">{daysAchieved}/7</span>
              </div>
              <p className="text-xs text-gray-600">Días logrados</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 text-blue-600">
                <Calendar className="w-4 h-4" />
                <span className="text-lg font-semibold">{currentStreak}</span>
              </div>
              <p className="text-xs text-gray-600">Racha actual</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pie Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Distribución de Logros</CardTitle>
          <CardDescription>
            Cómo te fue esta semana
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value, percent }) => `${name}: ${value} (${(percent * 100).toFixed(0)}%)`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          {/* Legend */}
          <div className="flex justify-center gap-6 mt-4">
            {pieData.map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: item.color }}
                ></div>
                <span className="text-sm text-gray-600">{item.name}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}