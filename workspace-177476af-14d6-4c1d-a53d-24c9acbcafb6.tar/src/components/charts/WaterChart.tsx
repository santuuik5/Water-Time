'use client';

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Droplets } from 'lucide-react';

interface ChartData {
  date: string;
  amount: number;
  goal: number;
  percentage: number;
}

interface WaterChartProps {
  data: ChartData[];
  title: string;
  description?: string;
  type?: 'line' | 'bar';
  period?: string;
}

export function WaterChart({ 
  data, 
  title, 
  description, 
  type = 'line', 
  period = 'daily' 
}: WaterChartProps) {
  const totalAmount = data.reduce((sum, item) => sum + item.amount, 0);
  const averageAmount = data.length > 0 ? Math.round(totalAmount / data.length) : 0;
  const goalAchieved = data.filter(item => item.percentage >= 100).length;
  const goalPercentage = data.length > 0 ? Math.round((goalAchieved / data.length) * 100) : 0;

  const formatXAxis = (tickItem: string) => {
    const date = new Date(tickItem);
    if (period === 'daily') {
      return date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
    } else if (period === 'weekly') {
      return `Sem ${Math.ceil(date.getDate() / 7)}`;
    }
    return date.toLocaleDateString('es-ES', { month: 'short' });
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border rounded-lg shadow-lg">
          <p className="font-medium text-sm">
            {new Date(label).toLocaleDateString('es-ES', {
              weekday: 'short',
              day: 'numeric',
              month: 'short'
            })}
          </p>
          <p className="text-blue-600 text-sm">
            <Droplets className="w-3 h-3 inline mr-1" />
            {payload[0].value}ml
          </p>
          <p className="text-gray-600 text-sm">
            Meta: {payload[0].payload.goal}ml
          </p>
          <p className="text-gray-500 text-xs">
            {Math.round(payload[0].payload.percentage)}% de la meta
          </p>
        </div>
      );
    }
    return null;
  };

  const ChartComponent = type === 'line' ? LineChart : BarChart;
  const DataComponent = type === 'line' ? Line : Bar;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Droplets className="w-5 h-5 text-blue-500" />
              {title}
            </CardTitle>
            {description && (
              <CardDescription>{description}</CardDescription>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              {goalPercentage}% logrado
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ChartComponent data={data}>
              <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
              <XAxis 
                dataKey="date" 
                tickFormatter={formatXAxis}
                className="text-xs"
              />
              <YAxis 
                className="text-xs"
                tickFormatter={(value) => `${value}ml`}
              />
              <Tooltip content={<CustomTooltip />} />
              <DataComponent
                type="monotone"
                dataKey="amount"
                stroke="#3b82f6"
                fill="#3b82f6"
                strokeWidth={2}
                dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            </ChartComponent>
          </ResponsiveContainer>
        </div>
        
        {/* Statistics */}
        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-blue-600">
              <Droplets className="w-4 h-4" />
              <span className="text-lg font-semibold">{totalAmount.toLocaleString()}</span>
            </div>
            <p className="text-xs text-gray-600">Total (ml)</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-green-600">
              <TrendingUp className="w-4 h-4" />
              <span className="text-lg font-semibold">{averageAmount.toLocaleString()}</span>
            </div>
            <p className="text-xs text-gray-600">Promedio (ml)</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-purple-600">
              <TrendingUp className="w-4 h-4" />
              <span className="text-lg font-semibold">{goalAchieved}</span>
            </div>
            <p className="text-xs text-gray-600">Metas logradas</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}