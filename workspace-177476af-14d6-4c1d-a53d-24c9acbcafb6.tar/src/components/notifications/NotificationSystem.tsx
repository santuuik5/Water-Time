'use client';

import { useState, useEffect, useCallback } from 'react';
import { Bell, BellOff, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useUserStore } from '@/store/useUserStore';
import { toast } from 'sonner';

interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
}

export function NotificationSystem() {
  const { user } = useUserStore();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isVisible, setIsVisible] = useState(false);

  // Request notification permission
  const requestPermission = useCallback(async () => {
    if ('Notification' in window) {
      const result = await Notification.requestPermission();
      setPermission(result);
      
      if (result === 'granted') {
        toast.success('Notificaciones activadas');
      } else {
        toast.error('Las notificaciones están bloqueadas');
      }
    }
  }, []);

  // Check initial permission
  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  // Schedule reminders
  useEffect(() => {
    if (!user?.reminderEnabled || permission !== 'granted') {
      return;
    }

    const scheduleReminder = () => {
      const now = new Date();
      const [startHour, startMinute] = user.reminderStart.split(':').map(Number);
      const [endHour, endMinute] = user.reminderEnd.split(':').map(Number);
      
      const startTime = new Date();
      startTime.setHours(startHour, startMinute, 0, 0);
      
      const endTime = new Date();
      endTime.setHours(endHour, endMinute, 0, 0);
      
      if (now >= startTime && now <= endTime) {
        // Show reminder
        showReminder();
        
        // Schedule next reminder
        setTimeout(scheduleReminder, user.reminderInterval * 60 * 1000);
      } else if (now < startTime) {
        // Schedule first reminder of the day
        const timeUntilStart = startTime.getTime() - now.getTime();
        setTimeout(scheduleReminder, timeUntilStart);
      } else {
        // Schedule first reminder for tomorrow
        const tomorrow = new Date(now);
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(startHour, startMinute, 0, 0);
        
        const timeUntilTomorrow = tomorrow.getTime() - now.getTime();
        setTimeout(scheduleReminder, timeUntilTomorrow);
      }
    };

    scheduleReminder();
  }, [user, permission]);

  const showReminder = useCallback(() => {
    if (!user || permission !== 'granted') return;

    const messages = [
      '¡Es hora de hidratarte! 💧',
      'Tu cuerpo te lo agradecerá 🌟',
      'Un vaso de agua para la energía ⚡',
      'Mantente fresco y saludable 🌿',
      'La hidratación es clave 🔑'
    ];

    const randomMessage = messages[Math.floor(Math.random() * messages.length)];

    // Browser notification
    const notification = new Notification('Water-Time', {
      body: randomMessage,
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      tag: 'water-reminder',
      requireInteraction: false,
      silent: false
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };

    // Add to in-app notifications
    const newNotification: Notification = {
      id: Date.now().toString(),
      title: 'Recordatorio de Agua',
      message: randomMessage,
      timestamp: new Date(),
      read: false
    };

    setNotifications(prev => [newNotification, ...prev]);

    // Auto-remove after 5 seconds
    setTimeout(() => {
      notification.close();
    }, 5000);
  }, [user, permission]);

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="relative">
      {/* Notification Bell */}
      <Button
        variant="outline"
        size="icon"
        onClick={() => setIsVisible(!isVisible)}
        className="relative"
      >
        {permission === 'granted' ? (
          <Bell className="w-4 h-4" />
        ) : (
          <BellOff className="w-4 h-4" />
        )}
        {unreadCount > 0 && (
          <Badge 
            variant="destructive" 
            className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center p-0 text-xs"
          >
            {unreadCount}
          </Badge>
        )}
      </Button>

      {/* Permission Request */}
      {permission === 'default' && (
        <Card className="absolute top-12 right-0 w-80 z-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Bell className="w-5 h-5 text-blue-500 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-medium">Activar Notificaciones</h4>
                <p className="text-sm text-gray-600 mt-1">
                  Recibe recordatorios para mantenerte hidratado durante el día.
                </p>
                <div className="flex gap-2 mt-3">
                  <Button size="sm" onClick={requestPermission}>
                    Activar
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setPermission('denied')}>
                    Ahora no
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Notifications Panel */}
      {isVisible && (
        <Card className="absolute top-12 right-0 w-96 z-50 max-h-96 overflow-hidden">
          <CardContent className="p-0">
            <div className="p-4 border-b flex items-center justify-between">
              <h4 className="font-medium">Notificaciones</h4>
              <div className="flex items-center gap-2">
                {notifications.length > 0 && (
                  <Button size="sm" variant="ghost" onClick={clearAll}>
                    Limpiar todo
                  </Button>
                )}
                <Button size="sm" variant="ghost" onClick={() => setIsVisible(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <div className="max-h-80 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No tienes notificaciones</p>
                </div>
              ) : (
                <div className="divide-y">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-gray-50 cursor-pointer transition-colors ${
                        !notification.read ? 'bg-blue-50' : ''
                      }`}
                      onClick={() => markAsRead(notification.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h5 className="font-medium text-sm">{notification.title}</h5>
                          <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                          <p className="text-xs text-gray-500 mt-2">
                            {notification.timestamp.toLocaleTimeString('es-ES', {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeNotification(notification.id);
                          }}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}