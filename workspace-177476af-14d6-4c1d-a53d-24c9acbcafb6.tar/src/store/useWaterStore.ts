import { create } from 'zustand';
import { WaterRecord, DailyStats } from '@/types';

interface WaterState {
  records: WaterRecord[];
  dailyStats: DailyStats | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setRecords: (records: WaterRecord[]) => void;
  addRecord: (record: WaterRecord) => void;
  updateRecord: (id: string, record: Partial<WaterRecord>) => void;
  deleteRecord: (id: string) => void;
  setDailyStats: (stats: DailyStats) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearError: () => void;
}

export const useWaterStore = create<WaterState>((set, get) => ({
  records: [],
  dailyStats: null,
  isLoading: false,
  error: null,

  setRecords: (records) => set({ records }),
  
  addRecord: (record) => set((state) => ({
    records: [...state.records, record]
  })),
  
  updateRecord: (id, updatedRecord) => set((state) => ({
    records: state.records.map(record => 
      record.id === id ? { ...record, ...updatedRecord } : record
    )
  })),
  
  deleteRecord: (id) => set((state) => ({
    records: state.records.filter(record => record.id !== id)
  })),
  
  setDailyStats: (stats) => set({ dailyStats: stats }),
  
  setLoading: (loading) => set({ isLoading: loading }),
  
  setError: (error) => set({ error }),
  
  clearError: () => set({ error: null })
}));