import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');
    const id = searchParams.get('id');

    if (email) {
      const user = await db.user.findUnique({
        where: { email },
        include: {
          waterRecords: {
            orderBy: { timestamp: 'desc' },
            take: 10
          },
          achievements: {
            orderBy: { unlockedAt: 'desc' },
            take: 5
          }
        }
      });

      if (!user) {
        return NextResponse.json(
          { error: 'User not found' },
          { status: 404 }
        );
      }

      return NextResponse.json(user);
    }

    if (id) {
      const user = await db.user.findUnique({
        where: { id },
        include: {
          waterRecords: {
            orderBy: { timestamp: 'desc' },
            take: 10
          },
          achievements: {
            orderBy: { unlockedAt: 'desc' },
            take: 5
          }
        }
      });

      if (!user) {
        return NextResponse.json(
          { error: 'User not found' },
          { status: 404 }
        );
      }

      return NextResponse.json(user);
    }

    const users = await db.user.findMany({
      include: {
        _count: {
          select: {
            waterRecords: true,
            achievements: true
          }
        }
      }
    });

    return NextResponse.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    return NextResponse.json(
      { error: 'Failed to fetch users' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, name, dailyGoal = 2000, weight, activityLevel } = body;

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 409 }
      );
    }

    const user = await db.user.create({
      data: {
        email,
        name,
        dailyGoal,
        weight,
        activityLevel
      }
    });

    return NextResponse.json(user, { status: 201 });
  } catch (error) {
    console.error('Error creating user:', error);
    return NextResponse.json(
      { error: 'Failed to create user' },
      { status: 500 }
    );
  }
}