import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const date = searchParams.get('date');

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    let whereClause: any = { userId };

    if (date) {
      const startDate = new Date(date);
      startDate.setHours(0, 0, 0, 0);
      const endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);
      
      whereClause.timestamp = {
        gte: startDate,
        lte: endDate
      };
    }

    const records = await db.waterRecord.findMany({
      where: whereClause,
      orderBy: { timestamp: 'desc' }
    });

    return NextResponse.json(records);
  } catch (error) {
    console.error('Error fetching water records:', error);
    return NextResponse.json(
      { error: 'Failed to fetch water records' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, amount, type = 'water', notes } = body;

    if (!userId || !amount) {
      return NextResponse.json(
        { error: 'User ID and amount are required' },
        { status: 400 }
      );
    }

    const record = await db.waterRecord.create({
      data: {
        userId,
        amount: parseInt(amount),
        type,
        notes
      }
    });

    return NextResponse.json(record, { status: 201 });
  } catch (error) {
    console.error('Error creating water record:', error);
    return NextResponse.json(
      { error: 'Failed to create water record' },
      { status: 500 }
    );
  }
}