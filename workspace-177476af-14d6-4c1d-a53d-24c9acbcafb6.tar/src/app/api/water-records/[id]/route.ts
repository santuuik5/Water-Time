import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { amount, type, notes } = body;

    const record = await db.waterRecord.update({
      where: { id: params.id },
      data: {
        ...(amount && { amount: parseInt(amount) }),
        ...(type && { type }),
        ...(notes !== undefined && { notes })
      }
    });

    return NextResponse.json(record);
  } catch (error) {
    console.error('Error updating water record:', error);
    return NextResponse.json(
      { error: 'Failed to update water record' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.waterRecord.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ message: 'Record deleted successfully' });
  } catch (error) {
    console.error('Error deleting water record:', error);
    return NextResponse.json(
      { error: 'Failed to delete water record' },
      { status: 500 }
    );
  }
}