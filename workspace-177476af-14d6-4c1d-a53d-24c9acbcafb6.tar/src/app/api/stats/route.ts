import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const period = searchParams.get('period') || 'today'; // today, week, month

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({
      where: { id: userId }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    let startDate: Date;
    const endDate = new Date();
    endDate.setHours(23, 59, 59, 999);

    switch (period) {
      case 'today':
        startDate = new Date();
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'week':
        startDate = new Date();
        startDate.setDate(startDate.getDate() - 7);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'month':
        startDate = new Date();
        startDate.setMonth(startDate.getMonth() - 1);
        startDate.setHours(0, 0, 0, 0);
        break;
      default:
        startDate = new Date();
        startDate.setHours(0, 0, 0, 0);
    }

    const records = await db.waterRecord.findMany({
      where: {
        userId,
        timestamp: {
          gte: startDate,
          lte: endDate
        }
      },
      orderBy: { timestamp: 'desc' }
    });

    const totalAmount = records.reduce((sum, record) => sum + record.amount, 0);
    const goalPercentage = user.dailyGoal > 0 ? (totalAmount / user.dailyGoal) * 100 : 0;

    // Calculate streak
    const streak = await calculateStreak(userId);

    // Group by day for charts
    const dailyStats = groupRecordsByDay(records, user.dailyGoal);

    const stats = {
      period,
      totalAmount,
      goalPercentage: Math.min(goalPercentage, 100),
      remaining: Math.max(0, user.dailyGoal - (period === 'today' ? totalAmount : 0)),
      recordCount: records.length,
      streak,
      dailyStats,
      averageDaily: period !== 'today' ? Math.round(totalAmount / Math.max(1, dailyStats.length)) : totalAmount
    };

    return NextResponse.json(stats);
  } catch (error) {
    console.error('Error fetching stats:', error);
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    );
  }
}

async function calculateStreak(userId: string): Promise<number> {
  const records = await db.waterRecord.findMany({
    where: { userId },
    orderBy: { timestamp: 'desc' },
    distinct: ['timestamp']
  });

  if (records.length === 0) return 0;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  let streak = 0;
  let currentDate = new Date(today);
  
  // Check if there's a record for today
  const todayRecord = records.find(record => {
    const recordDate = new Date(record.timestamp);
    recordDate.setHours(0, 0, 0, 0);
    return recordDate.getTime() === today.getTime();
  });
  
  if (!todayRecord) {
    // If no record today, check yesterday
    currentDate.setDate(currentDate.getDate() - 1);
  }
  
  // Count consecutive days
  while (true) {
    const dayStart = new Date(currentDate);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(currentDate);
    dayEnd.setHours(23, 59, 59, 999);
    
    const dayRecord = records.find(record => {
      const recordDate = new Date(record.timestamp);
      return recordDate >= dayStart && recordDate <= dayEnd;
    });
    
    if (dayRecord) {
      streak++;
      currentDate.setDate(currentDate.getDate() - 1);
    } else {
      break;
    }
  }
  
  return streak;
}

function groupRecordsByDay(records: any[], dailyGoal: number) {
  const grouped: { [key: string]: { amount: number; count: number } } = {};
  
  records.forEach(record => {
    const date = new Date(record.timestamp).toDateString();
    if (!grouped[date]) {
      grouped[date] = { amount: 0, count: 0 };
    }
    grouped[date].amount += record.amount;
    grouped[date].count += 1;
  });
  
  return Object.entries(grouped).map(([date, data]) => ({
    date,
    totalAmount: data.amount,
    goalPercentage: Math.min((data.amount / dailyGoal) * 100, 100),
    recordCount: data.count
  })).reverse();
}