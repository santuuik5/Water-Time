import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, message, type = 'reminder' } = body;

    if (!userId || !message) {
      return NextResponse.json(
        { error: 'User ID and message are required' },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({
      where: { id: userId }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Check if reminders are enabled
    if (!user.reminderEnabled) {
      return NextResponse.json(
        { error: 'Reminders are disabled for this user' },
        { status: 400 }
      );
    }

    // Check current time is within reminder hours
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5);
    const [currentHour, currentMinute] = currentTime.split(':').map(Number);
    
    const [startHour, startMinute] = user.reminderStart.split(':').map(Number);
    const [endHour, endMinute] = user.reminderEnd.split(':').map(Number);
    
    const currentMinutes = currentHour * 60 + currentMinute;
    const startMinutes = startHour * 60 + startMinute;
    const endMinutes = endHour * 60 + endMinute;
    
    if (currentMinutes < startMinutes || currentMinutes > endMinutes) {
      return NextResponse.json(
        { error: 'Current time is outside reminder hours' },
        { status: 400 }
      );
    }

    // Generate personalized reminder message using AI
    const zai = await ZAI.create();
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: `Eres un asistente de hidratación amigable y motivador. Genera mensajes personalizados para recordar a las personas que beban agua. 
          El usuario se llama ${user.name || 'amigo'} y su meta diaria es ${user.dailyGoal}ml. 
          El mensaje debe ser corto, motivador y personalizado. Máximo 100 caracteres.`
        },
        {
          role: 'user',
          content: message || 'Recuérdame beber agua'
        }
      ],
      max_tokens: 100,
      temperature: 0.7
    });

    const personalizedMessage = aiResponse.choices[0]?.message?.content || message;

    // Here you would typically send a push notification, email, or SMS
    // For this demo, we'll just log it and return success
    console.log(`Reminder sent to ${user.email}: ${personalizedMessage}`);

    // In a real app, you would integrate with:
    // - Push notifications (Firebase, OneSignal, etc.)
    // - Email service (SendGrid, AWS SES, etc.)
    // - SMS service (Twilio, etc.)
    // - Web notifications

    return NextResponse.json({
      success: true,
      message: personalizedMessage,
      timestamp: new Date().toISOString(),
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });

  } catch (error) {
    console.error('Error sending reminder:', error);
    return NextResponse.json(
      { error: 'Failed to send reminder' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({
      where: { id: userId }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5);
    
    return NextResponse.json({
      enabled: user.reminderEnabled,
      interval: user.reminderInterval,
      start: user.reminderStart,
      end: user.reminderEnd,
      currentTime,
      nextReminder: calculateNextReminder(user)
    });

  } catch (error) {
    console.error('Error fetching reminder settings:', error);
    return NextResponse.json(
      { error: 'Failed to fetch reminder settings' },
      { status: 500 }
    );
  }
}

function calculateNextReminder(user: any): string {
  const now = new Date();
  const nextReminder = new Date(now.getTime() + user.reminderInterval * 60 * 1000);
  
  const [endHour, endMinute] = user.reminderEnd.split(':').map(Number);
  const endTime = new Date();
  endTime.setHours(endHour, endMinute, 0, 0);
  
  if (nextReminder > endTime) {
    return 'Mañana';
  }
  
  return nextReminder.toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit'
  });
}