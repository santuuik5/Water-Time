'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Droplets, Target, TrendingUp, Clock, Plus, Settings } from 'lucide-react';
import { useWaterStore } from '@/store/useWaterStore';
import { useUserStore } from '@/store/useUserStore';
import { WaterRecord } from '@/types';
import { NotificationSystem } from '@/components/notifications/NotificationSystem';
import { Dashboard } from '@/components/dashboard/Dashboard';
import { SettingsModal } from '@/components/settings/SettingsModal';

export default function Home() {
  const { records, addRecord, setRecords, isLoading } = useWaterStore();
  const { user, setUser } = useUserStore();
  const [selectedAmount, setSelectedAmount] = useState(250);
  const [activeTab, setActiveTab] = useState('home');
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Mock user data for demo
  useEffect(() => {
    if (!user) {
      setUser({
        id: '1',
        email: 'demo@example.com',
        name: 'Usuario Demo',
        dailyGoal: 2000,
        reminderEnabled: true,
        reminderInterval: 60,
        reminderStart: '08:00',
        reminderEnd: '22:00',
        createdAt: new Date(),
        updatedAt: new Date()
      });
    }
  }, [user, setUser]);

  // Mock records for demo
  useEffect(() => {
    if (records.length === 0) {
      const mockRecords: WaterRecord[] = [
        {
          id: '1',
          userId: '1',
          amount: 250,
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
          type: 'water',
          notes: 'Vaso de agua'
        },
        {
          id: '2',
          userId: '1',
          amount: 500,
          timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
          type: 'water',
          notes: 'Botella'
        }
      ];
      setRecords(mockRecords);
    }
  }, [records, setRecords]);

  const todayIntake = records
    .filter(record => {
      const today = new Date();
      const recordDate = new Date(record.timestamp);
      return recordDate.toDateString() === today.toDateString();
    })
    .reduce((total, record) => total + record.amount, 0);

  const goalPercentage = user ? (todayIntake / user.dailyGoal) * 100 : 0;
  const remaining = user ? Math.max(0, user.dailyGoal - todayIntake) : 0;

  const handleAddWater = async (amount: number) => {
    const newRecord: WaterRecord = {
      id: Date.now().toString(),
      userId: user?.id || '1',
      amount,
      timestamp: new Date(),
      type: 'water',
      notes: `${amount}ml de agua`
    };
    
    addRecord(newRecord);
  };

  const quickAmounts = [150, 250, 350, 500, 750, 1000];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
              <Droplets className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Water-Time</h1>
              <p className="text-sm text-gray-600">Tu recordatorio de hidratación</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <NotificationSystem />
            <Button variant="outline" size="icon" onClick={() => setSettingsOpen(true)}>
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </header>

        {/* Main Navigation */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="home">Inicio</TabsTrigger>
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          </TabsList>

          <TabsContent value="home" className="space-y-6">
            {/* Main Content */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Progress Card */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-blue-500" />
                    Progreso Diario
                  </CardTitle>
                  <CardDescription>
                    {new Date().toLocaleDateString('es-ES', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Progress Circle */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-48 h-48">
                      <svg className="transform -rotate-90 w-48 h-48">
                        <circle
                          cx="96"
                          cy="96"
                          r="88"
                          stroke="currentColor"
                          strokeWidth="12"
                          fill="none"
                          className="text-gray-200"
                        />
                        <circle
                          cx="96"
                          cy="96"
                          r="88"
                          stroke="currentColor"
                          strokeWidth="12"
                          fill="none"
                          strokeDasharray={`${2 * Math.PI * 88}`}
                          strokeDashoffset={`${2 * Math.PI * 88 * (1 - Math.min(goalPercentage / 100, 1))}`}
                          className="text-blue-500 transition-all duration-500"
                        />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-3xl font-bold text-gray-900">
                          {Math.round(goalPercentage)}%
                        </span>
                        <span className="text-sm text-gray-600">
                          {todayIntake}ml / {user?.dailyGoal || 2000}ml
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progreso</span>
                      <span>{remaining}ml restantes</span>
                    </div>
                    <Progress value={Math.min(goalPercentage, 100)} className="h-3" />
                  </div>

                  {/* Quick Add Buttons */}
                  <div className="space-y-3">
                    <h3 className="text-sm font-medium">Agregar agua rápidamente:</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {quickAmounts.map((amount) => (
                        <Button
                          key={amount}
                          variant="outline"
                          onClick={() => handleAddWater(amount)}
                          className="flex items-center gap-2"
                        >
                          <Droplets className="w-4 h-4 text-blue-500" />
                          {amount}ml
                        </Button>
                      ))}
                    </div>
                    <Button 
                      onClick={() => handleAddWater(selectedAmount)}
                      className="w-full"
                      size="lg"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Agregar {selectedAmount}ml
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Stats Card */}
              <div className="space-y-6">
                {/* Today's Stats */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-green-500" />
                      Estadísticas
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Consumos hoy</span>
                      <Badge variant="secondary">
                        {records.filter(r => {
                          const today = new Date();
                          const recordDate = new Date(r.timestamp);
                          return recordDate.toDateString() === today.toDateString();
                        }).length}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Racha actual</span>
                      <Badge variant="secondary">3 días</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Próximo recordatorio</span>
                      <Badge variant="outline">
                        <Clock className="w-3 h-3 mr-1" />
                        En 45 min
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Records */}
                <Card>
                  <CardHeader>
                    <CardTitle>Registros Recientes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-64 overflow-y-auto">
                      {records
                        .filter(record => {
                          const today = new Date();
                          const recordDate = new Date(record.timestamp);
                          return recordDate.toDateString() === today.toDateString();
                        })
                        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                        .slice(0, 5)
                        .map((record) => (
                          <div key={record.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <div className="flex items-center gap-2">
                              <Droplets className="w-4 h-4 text-blue-500" />
                              <div>
                                <p className="text-sm font-medium">{record.amount}ml</p>
                                <p className="text-xs text-gray-500">{record.notes}</p>
                              </div>
                            </div>
                            <span className="text-xs text-gray-500">
                              {new Date(record.timestamp).toLocaleTimeString('es-ES', {
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Tips Section */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Consejos de Hidratación</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="general" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="general">General</TabsTrigger>
                    <TabsTrigger value="benefits">Beneficios</TabsTrigger>
                    <TabsTrigger value="tips">Consejos</TabsTrigger>
                  </TabsList>
                  <TabsContent value="general" className="mt-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <h4 className="font-medium text-blue-900 mb-2">¿Cuánta agua necesitas?</h4>
                        <p className="text-sm text-blue-700">
                          La recomendación general es de 2 litros diarios, pero puede variar según tu peso, 
                          nivel de actividad y clima.
                        </p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-lg">
                        <h4 className="font-medium text-green-900 mb-2">Mejores momentos</h4>
                        <p className="text-sm text-green-700">
                          Bebe agua al despertar, antes de las comidas, durante el ejercicio y antes de dormir.
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="benefits" className="mt-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 bg-purple-50 rounded-lg">
                        <h4 className="font-medium text-purple-900 mb-2">Energía</h4>
                        <p className="text-sm text-purple-700">
                          Mejora los niveles de energía y función cerebral
                        </p>
                      </div>
                      <div className="p-4 bg-yellow-50 rounded-lg">
                        <h4 className="font-medium text-yellow-900 mb-2">Piel</h4>
                        <p className="text-sm text-yellow-700">
                          Mantiene la piel hidratada y saludable
                        </p>
                      </div>
                      <div className="p-4 bg-red-50 rounded-lg">
                        <h4 className="font-medium text-red-900 mb-2">Digestión</h4>
                        <p className="text-sm text-red-700">
                          Ayuda en la digestión y previene el estreñimiento
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="tips" className="mt-4">
                    <div className="space-y-3">
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                        <p className="text-sm">Lleva siempre contigo una botella de agua reutilizable</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                        <p className="text-sm">Usa aplicaciones o alarmas para recordarte beber agua</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                        <p className="text-sm">Añade frutas o hierbas para darle sabor al agua</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                        <p className="text-sm">Bebe un vaso de agua antes de cada comida</p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="dashboard">
            <Dashboard />
          </TabsContent>
        </Tabs>
      </div>

      {/* Settings Modal */}
      <SettingsModal open={settingsOpen} onOpenChange={setSettingsOpen} />
    </div>
  );
}