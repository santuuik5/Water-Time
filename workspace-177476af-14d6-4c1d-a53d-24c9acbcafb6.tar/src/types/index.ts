export interface User {
  id: string;
  email: string;
  name?: string;
  avatar?: string;
  dailyGoal: number;
  weight?: number;
  activityLevel?: 'sedentary' | 'light' | 'moderate' | 'active';
  reminderEnabled: boolean;
  reminderInterval: number;
  reminderStart: string;
  reminderEnd: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface WaterRecord {
  id: string;
  userId: string;
  amount: number;
  timestamp: Date;
  type: string;
  notes?: string;
}

export interface Achievement {
  id: string;
  userId: string;
  type: string;
  title: string;
  description: string;
  icon?: string;
  unlockedAt: Date;
}

export interface DailyStats {
  date: string;
  totalAmount: number;
  goalPercentage: number;
  recordCount: number;
  streak: number;
}

export interface WaterIntake {
  id: string;
  amount: number;
  type: string;
  timestamp: Date;
  notes?: string;
}

export interface ReminderSettings {
  enabled: boolean;
  interval: number;
  start: string;
  end: string;
}