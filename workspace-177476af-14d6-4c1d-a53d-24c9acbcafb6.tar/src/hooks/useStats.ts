import { useState, useEffect } from 'react';
import { useUserStore } from '@/store/useUserStore';

interface StatsData {
  period: string;
  totalAmount: number;
  goalPercentage: number;
  remaining: number;
  recordCount: number;
  streak: number;
  dailyStats: Array<{
    date: string;
    totalAmount: number;
    goalPercentage: number;
    recordCount: number;
  }>;
  averageDaily: number;
}

export function useStats(period: 'today' | 'week' | 'month' = 'today') {
  const { user } = useUserStore();
  const [stats, setStats] = useState<StatsData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;

    const fetchStats = async () => {
      setIsLoading(true);
      setError(null);

      try {
        const response = await fetch(`/api/stats?userId=${user.id}&period=${period}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch stats');
        }

        const data = await response.json();
        setStats(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setIsLoading(false);
      }
    };

    fetchStats();
  }, [user, period]);

  return { stats, isLoading, error };
}