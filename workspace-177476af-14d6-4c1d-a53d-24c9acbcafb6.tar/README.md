# Water-Time - Aplicación de Recordatorio de Hidratación

Una aplicación web moderna y completa para ayudar a los usuarios a mantenerse hidratados durante el día, con recordatorios personalizados, seguimiento de consumo y análisis detallado de hábitos.

## 🌟 Características Principales

### 💧 Gestión de Consumo de Agua
- Registro rápido y fácil de consumo de agua
- Botones de acceso rápido para cantidades predefinidas (150ml, 250ml, 350ml, 500ml, 750ml, 1000ml)
- Seguimiento en tiempo real del progreso diario
- Visualización con círculo de progreso y barra de progreso

### 📊 Dashboard Analítico
- Estadísticas detalladas de consumo (diario, semanal, mensual)
- Gráficos interactivos de tendencias
- Análisis de patrones de consumo
- Métricas de rendimiento y metas alcanzadas

### 🔔 Sistema de Recordatorios Inteligentes
- Notificaciones personalizables del navegador
- Intervalos configurables (15-180 minutos)
- Horarios personalizables de inicio y fin
- Mensajes motivadores generados por IA

### ⚙️ Configuración Personalizada
- Metas diarias ajustables (500-4000ml)
- Perfil de usuario con peso y nivel de actividad
- Cálculo automático de metas recomendadas
- Preferencias de recordatorios

### 📱 Diseño Responsivo
- Interfaz moderna con shadcn/ui
- Totalmente responsiva para móviles y escritorio
- Tema claro con gradientes atractivos
- Navegación intuitiva con pestañas

## 🏗️ Arquitectura Técnica

### Stack Tecnológico

**Frontend:**
- **Next.js 15** con App Router
- **TypeScript 5** para tipado seguro
- **Tailwind CSS 4** para estilos modernos
- **shadcn/ui** para componentes de UI consistentes
- **Zustand** para gestión de estado local
- **TanStack Query** para estado del servidor
- **Recharts** para visualización de datos
- **Lucide React** para iconos

**Backend:**
- **Next.js API Routes** para endpoints REST
- **Prisma ORM** con base de datos SQLite
- **z-ai-web-dev-sdk** para funcionalidades de IA
- **Validación de datos y manejo de errores**

**Base de Datos:**
- **SQLite** con Prisma ORM
- Modelo relacional optimizado
- Índices para consultas eficientes

### Estructura del Proyecto

```
src/
├── app/                    # Páginas y API Routes
│   ├── api/               # Endpoints de la API
│   │   ├── users/         # Gestión de usuarios
│   │   ├── water-records/ # Registros de consumo
│   │   ├── stats/         # Estadísticas
│   │   └── reminders/     # Recordatorios
│   ├── components/        # Componentes de la página
│   └── page.tsx          # Página principal
├── components/            # Componentes reutilizables
│   ├── ui/               # Componentes shadcn/ui
│   ├── charts/           # Componentes de gráficos
│   ├── dashboard/        # Componentes del dashboard
│   ├── notifications/    # Sistema de notificaciones
│   └── settings/         # Configuración
├── store/                # Zustand stores
│   ├── useWaterStore.ts  # Estado de consumo de agua
│   └── useUserStore.ts   # Estado de usuario
├── hooks/                # Custom hooks
│   └── useStats.ts       # Hook para estadísticas
├── types/                # Tipos TypeScript
│   └── index.ts          # Definiciones de tipos
├── lib/                  # Utilidades
│   ├── db.ts            # Cliente Prisma
│   └── utils.ts         # Funciones utilitarias
└── prisma/               # Configuración de base de datos
    └── schema.prisma     # Esquema de la base de datos
```

## 🚀 Instalación y Configuración

### Prerrequisitos
- Node.js 18+ 
- npm o yarn

### Pasos de Instalación

1. **Clonar el repositorio**
```bash
git clone <repository-url>
cd water-time
```

2. **Instalar dependencias**
```bash
npm install
```

3. **Configurar variables de entorno**
```bash
cp .env.example .env.local
```

4. **Configurar la base de datos**
```bash
npm run db:push
```

5. **Iniciar el servidor de desarrollo**
```bash
npm run dev
```

6. **Abrir la aplicación**
```bash
# La aplicación estará disponible en http://localhost:3000
```

## 📡 API Endpoints

### Usuarios
- `GET /api/users` - Obtener todos los usuarios
- `POST /api/users` - Crear nuevo usuario
- `GET /api/users/[id]` - Obtener usuario por ID
- `PUT /api/users/[id]` - Actualizar usuario
- `DELETE /api/users/[id]` - Eliminar usuario

### Registros de Agua
- `GET /api/water-records` - Obtener registros (con filtros)
- `POST /api/water-records` - Crear nuevo registro
- `PUT /api/water-records/[id]` - Actualizar registro
- `DELETE /api/water-records/[id]` - Eliminar registro

### Estadísticas
- `GET /api/stats` - Obtener estadísticas (por período y usuario)

### Recordatorios
- `GET /api/reminders` - Obtener configuración de recordatorios
- `POST /api/reminders` - Enviar recordatorio

## 🗄️ Modelo de Datos

### User
```typescript
interface User {
  id: string
  email: string
  name?: string
  avatar?: string
  dailyGoal: number          // Meta diaria en ml
  weight?: number           // Peso en kg
  activityLevel?: string    // Nivel de actividad
  reminderEnabled: boolean  // Recordatorios activados
  reminderInterval: number  // Intervalo en minutos
  reminderStart: string     // Hora de inicio
  reminderEnd: string       // Hora de fin
  createdAt: Date
  updatedAt: Date
}
```

### WaterRecord
```typescript
interface WaterRecord {
  id: string
  userId: string
  amount: number           // Cantidad en ml
  timestamp: Date
  type: string            // Tipo de bebida
  notes?: string          // Notas adicionales
}
```

### Achievement
```typescript
interface Achievement {
  id: string
  userId: string
  type: string            // Tipo de logro
  title: string
  description: string
  icon?: string
  unlockedAt: Date
}
```

## 🎯 Funcionalidades Clave

### 1. Registro de Consumo
- **Quick Add**: Botones rápidos para cantidades comunes
- **Custom Amount**: Posibilidad de agregar cantidades personalizadas
- **Real-time Update**: Actualización inmediata del progreso
- **Visual Feedback**: Animaciones y transiciones suaves

### 2. Sistema de Recordatorios
- **Browser Notifications**: Notificaciones nativas del navegador
- **Smart Scheduling**: Solo dentro del horario configurado
- **AI-powered Messages**: Mensajes personalizados generados por IA
- **Permission Management**: Manejo elegante de permisos

### 3. Dashboard Analítico
- **Multi-period Analysis**: Diario, semanal y mensual
- **Interactive Charts**: Gráficos de líneas y barras interactivos
- **Progress Tracking**: Seguimiento de metas y rachas
- **Insights**: Recomendaciones basadas en patrones

### 4. Configuración Personalizada
- **Goal Calculator**: Cálculo automático basado en peso y actividad
- **Flexible Reminders**: Configuración detallada de recordatorios
- **User Profile**: Información personal para mejor experiencia
- **Privacy First**: Todos los datos almacenados localmente

## 🔧 Desarrollo

### Scripts Disponibles
```bash
npm run dev          # Iniciar servidor de desarrollo
npm run build        # Construir para producción
npm run start        # Iniciar servidor de producción
npm run lint         # Ejecutar ESLint
npm run db:push      # Sincronizar esquema de base de datos
npm run db:studio    # Abrir Prisma Studio
```

### Buenas Prácticas
- **TypeScript**: Tipado estricto en todo el código
- **Component-based**: Componentes reutilizables y modulares
- **State Management**: Zustand para estado local eficiente
- **Error Handling**: Manejo robusto de errores
- **Responsive Design**: Mobile-first approach
- **Performance**: Optimización de renderizado y consultas

## 🧪 Pruebas

### Pruebas Unitarias
```bash
npm run test          # Ejecutar pruebas unitarias
npm run test:watch    # Modo watch para desarrollo
npm run test:coverage  # Generar reporte de cobertura
```

### Pruebas E2E
```bash
npm run test:e2e      # Pruebas end-to-end
npm run test:e2e:ui   # Interfaz visual para pruebas E2E
```

## 🚀 Despliegue

### Vercel (Recomendado)
1. Conectar repositorio a Vercel
2. Configurar variables de entorno
3. Despliegue automático en cada push

### Docker
```bash
# Construir imagen
docker build -t water-time .

# Ejecutar contenedor
docker run -p 3000:3000 water-time
```

### Producción
```bash
npm run build
npm run start
```

## 🔐 Seguridad

### Medidas de Seguridad
- **Input Validation**: Validación de todos los inputs
- **SQL Injection Protection**: Prisma ORM previene inyecciones
- **XSS Prevention**: Sanitización de datos
- **CORS Configuration**: Configuración adecuada de CORS
- **Environment Variables**: Variables sensibles en entorno

### Recomendaciones
- Usar HTTPS en producción
- Configurar headers de seguridad
- Implementar rate limiting
- Regularmente actualizar dependencias

## 📈 Monitoreo y Rendimiento

### Métricas Clave
- **Core Web Vitals**: Optimización de experiencia de usuario
- **Bundle Size**: Mantener el tamaño del bundle óptimo
- **API Response Time**: Tiempos de respuesta rápidos
- **Database Performance**: Consultas optimizadas

### Herramientas
- **Lighthouse**: Auditoría de rendimiento
- **Chrome DevTools**: Depuración y análisis
- **Prisma Studio**: Visualización de base de datos

## 🤝 Contribución

### Flujo de Trabajo
1. Fork del repositorio
2. Crear rama de feature (`git checkout -b feature/amazing-feature`)
3. Commit de cambios (`git commit -m 'Add amazing feature'`)
4. Push a la rama (`git push origin feature/amazing-feature`)
5. Abrir Pull Request

### Guía de Estilo
- Seguir convenciones de código de TypeScript
- Usar componentes shadcn/ui cuando sea posible
- Escribir tests para nuevas funcionalidades
- Documentar cambios importantes

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo [LICENSE](LICENSE) para más detalles.

## 🆘 Soporte

### FAQ
- **P: ¿Cómo funcionan los recordatorios?**
  R: Los recordatorios usan la API de notificaciones del navegador y requieren permiso del usuario.

- **P: ¿Los datos se sincronizan en la nube?**
  R: Actualmente los datos se almacenan localmente, pero la arquitectura soporta fácilmente la adición de sincronización.

- **P: ¿Puedo usar la aplicación sin conexión?**
  R: Sí, la aplicación funciona completamente offline una vez cargada.

### Contacto
- **Issues**: Reportar problemas en GitHub Issues
- **Email**: [support@water-time.com]
- **Discord**: [Servidor de la comunidad]

## 🗺️ Roadmap

### Próximas Funcionalidades
- [ ] Sincronización en la nube
- [ ] Aplicación móvil nativa
- [ ] Integración con wearables
- [ ] Modo oscuro
- [ ] Más tipos de bebidas
- [ ] Metas grupales
- [ ] Sistema de logros extendido
- [ ] Integración con asistentes de voz

### Mejoras Técnicas
- [ ] PWA (Progressive Web App)
- [ ] Offline-first architecture
- [ ] Microservicios
- [ ] Machine Learning para predicciones
- [ ] Real-time collaboration

---

**Water-Time** © 2024 - Mantente hidratado, mantente saludable 💧